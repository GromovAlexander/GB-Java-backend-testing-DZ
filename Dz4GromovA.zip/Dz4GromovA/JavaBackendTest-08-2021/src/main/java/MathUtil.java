public final class MathUtil {

    private MathUtil() {}

    public static int sum(int a, int b) {
        return a + b;
    }

}
