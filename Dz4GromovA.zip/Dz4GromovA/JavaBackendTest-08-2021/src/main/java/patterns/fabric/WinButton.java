package patterns.fabric;

public class WinButton implements Button {
    @Override
    public void onClick() {
        // TODO: 25.08.2021  
    }
}
