package patterns.proxy;

public interface Calculator {
    int calculate();
}
