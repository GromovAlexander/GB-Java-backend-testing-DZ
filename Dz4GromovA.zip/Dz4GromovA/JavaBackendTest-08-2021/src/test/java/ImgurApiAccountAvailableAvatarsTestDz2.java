import java.io.IOException;

import io.restassured.RestAssured;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

class ImgurApiAccountAvailableAvatarsTestDz2 extends BaseApiTestDz {

    public ImgurApiAccountAvailableAvatarsTestDz2() throws IOException {
    }

    @BeforeEach
    void setUp() {
        RestAssured.baseURI = getBaseUriDz();
    }
    @BeforeEach
    void beforeTest() {
        responseSpecification = new ResponseSpecBuilder()
                .expectContentType(ContentType.JSON)
                .expectStatusCode(200)
                .expectBody("success", is(true))
                .build();
    }


    @AfterEach
    void tearDown() {
    }

    @Test
    @DisplayName("Получение информации об аккаунте")
    void testAccountAvailableAvatarsTestDz() {

        System.out.println("\n" + "*****************");
        System.out.println("*Результат теста*");
        System.out.println("*****************" + "\n");

        given()
                .accept(ContentType.JSON)
                .auth()
                .oauth2(getTokenDz())
                .expect()
                .spec(responseSpecification)
                .log()
                .all()
                .body("data.avatar_name", is("default/R"))
                .when()
                .get("3/account/{username}/avatar", getUserNameDz());
    }

    @Test
    @DisplayName("Получение статуса кода 200")
    void testGetStatusOkDz() {
        System.out.println("\n" + "*****************");
        System.out.println("*Результат теста*");
        System.out.println("*****************" + "\n");
        get().statusCode();
        if (get().statusCode() == 200) {
            System.out.println("Статус кода: " + get().statusCode());
        } else
            System.out.println("Тест завален");
    }

    @Test
    @DisplayName("В теле имеется запрошенная строка")
    void testGetResponseString() {
        System.out.println("\n" + "*****************");
        System.out.println("*Результат теста*");
        System.out.println("*****************" + "\n");
        get("data");
        System.out.println("К сожалению, не получается вытянуть другую информацию из ответа");
    }

}