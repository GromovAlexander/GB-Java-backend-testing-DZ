package patterns.fabric;

public interface ButtonFabric {
    Button createButton();
}
