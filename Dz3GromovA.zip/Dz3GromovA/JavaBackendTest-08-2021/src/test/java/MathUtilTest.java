import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.stream.Stream;
import java.util.Arrays;

import org.junit.Test;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.io.TempDir;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

import static java.lang.Math.abs;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.params.provider.Arguments.arguments;

//@RunWith(Parameterized.class)
class MathUtilTest {

//    private static Stream<Arguments> getDataForSumTest() {
//        return Stream.of(
//                arguments(10, 7, 17),
//                arguments(15, 10, 25),
//                arguments(1, 2, 3)
//        );
//    }

    //    int a, b;
//    int a, b, c;
//
//    public MathUtilTest(int a, int b, int c) {
//        this.a = a;
//        this.b = b;
//        this.c = c;
//    }


//    @Parameterized.Parameters(name = "{index}:sumOf({0}+{1})={2}")
//    public static Iterable<Object[]> dataForTest() {
//        return Arrays.asList(new Object[][]{
//                {1, 1, 2},
//                {2, 6, 8},
//                {18, 2, 20},
//                {13, 15, 28},
//                {1, 5, 6}
//        });
//    }

    @BeforeEach
    void setUp() {
//        a = getRandomInt(10, 100);
//        b = getRandomInt(10, 100);
    }

    @AfterEach
    void tearDown() {

    }

//    @Test
//    @DisplayName("Тест суммы двух чисел")
//    void sumTest() {
//        int actually = MathUtil.sum(1,2);
//        assertEquals(3, actually);
//    }

//    @Test
//    @Test
//    @DisplayName("Тест суммы двух чисел")
//    public void sumTest() {
//        int actually = MathUtil.sum(a,b);
////        int expected = a + b;
//        int expected = c;
////        assertEquals(expected, actually);
//        assertEquals(c, actually);
//    }

//    @ParameterizedTest
//    @DisplayName("Тест суммы двух чисел")
//    @MethodSource("getDataForSumTest")
//    void sumTest(int a, int b, int expected) {
//        int actually = MathUtil.sum(a, b);
//        assertEquals(expected, actually);
//    }
//
//    @Test
//    @DisplayName("Тест на создание временного файла")
//    void fileCreationTest(@TempDir Path path) throws IOException {
//        Path file = Files.createFile(path.resolve("test.txt"));
//        Files.writeString(file, "Hello world!");
//        assertTrue(Files.exists(file));
//    }
//
//    private int getRandomInt(int from, int to) {
//        int length = abs(to - from);
//        return (int) (from + Math.random() * length);
//    }

}