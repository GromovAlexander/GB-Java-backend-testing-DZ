
import java.io.IOException;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import static io.restassured.RestAssured.*;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

class ImgurApiAccountBaseTestDz extends BaseApiTestDz {

    public ImgurApiAccountBaseTestDz() throws IOException {
    }

    @BeforeEach
    void setUp() {
        RestAssured.baseURI = getBaseUriDz();
    }


    @AfterEach
    void tearDown() {
    }

    @Test
    @DisplayName("Получение информации об аккаунте")
    void testGetAccountBaseDz() {

        System.out.println("\n" + "*****************");
        System.out.println("*Результат теста*");
        System.out.println("*****************" + "\n");

        given()
                .contentType(ContentType.JSON)
                .accept(ContentType.JSON)
                .auth()
                .oauth2(getTokenDz())
                .expect()
                .body("data.url", is("RynerLute89"))
                .log()
                .all()
                .statusCode(200)
                .when()
                .get("3/account/{username}", getUserNameDz());
    }

    @Test
    @DisplayName("Получение статуса кода 200")
    void testGetStatusOkDz() {
        System.out.println("\n" + "*****************");
        System.out.println("*Результат теста*");
        System.out.println("*****************" + "\n");
//        testGetAccountBaseDz();
        get().statusCode();
        if (get().statusCode() == 200) {
            System.out.println("Статус кода: " + get().statusCode());
        } else
        System.out.println("Тест завален");
    }

    @Test
    @DisplayName("В теле имеется запрошенная строка")
    void testGetResponseString() {
        System.out.println("\n" + "*****************");
        System.out.println("*Результат теста*");
        System.out.println("*****************" + "\n");
        System.out.println("Пытаюсь разобраться");
        get().body();
    }

}