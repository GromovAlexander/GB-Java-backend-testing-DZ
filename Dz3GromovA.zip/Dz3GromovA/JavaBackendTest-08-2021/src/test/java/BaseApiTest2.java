import java.io.IOException;

abstract class BaseApiTestDz {

    private final String tokenDz;
    private final String baseUriDz;
    private final String userNameDz;
    private final PropertyScanner scannerDz;

    public BaseApiTestDz() throws IOException {
        scannerDz = new PropertyScanner();
        tokenDz = scannerDz.getProperty("imgur.auth.token.dz");
        baseUriDz = scannerDz.getProperty("imgur.api.url.dz");
        userNameDz = scannerDz.getProperty("imgur.username.dz");
    }

    public String getTokenDz() {
        return tokenDz;
    }

    public String getBaseUriDz() {
        return baseUriDz;
    }

    public String getUserNameDz() {
        return userNameDz;
    }

    public PropertyScanner getScannerDz() {
        return scannerDz;
    }
}