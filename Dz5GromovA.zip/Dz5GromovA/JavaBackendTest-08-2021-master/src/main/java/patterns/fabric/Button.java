package patterns.fabric;

public interface Button {
    void onClick();
}
